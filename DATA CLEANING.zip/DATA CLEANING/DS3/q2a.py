import pandas as pd
df = pd.read_csv('landslide_data_miss.csv')
df = df.dropna(subset=['stationid'])
df = df.dropna(thresh=int(len(df.columns)/3))

print(df)