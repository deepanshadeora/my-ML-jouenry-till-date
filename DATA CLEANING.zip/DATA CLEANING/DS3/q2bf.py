import pandas as pd
import numpy as np


def linear_interpolation(x_prev, x_next, y_prev, y_next, x_define):

    slope =(((x_define - x_prev) / (x_next - x_prev)))
    return y_prev+ (slope*(y_next-y_prev))
df = pd.read_csv("landslide_data_miss.csv")
df["dates"]=pd.to_datetime(df["dates"],dayfirst=True)
df.dropna(subset=['stationid'],inplace=True)
df= df.drop(df[df.isna().sum(axis=1)>2].index)
df.reset_index(inplace=True,drop=True)
# k=df.shape[1]-1
# def fill_missing_values(df):
#     for i in range(len(df)):
#             if pd.isnull(df.iloc[i, k]):
#                 if i == 0:
#                     y_prev = None
#                 else:
#                     y_prev = df.iloc[i - 1, k]

def fill_missing_values(df):
    for i in range(len(df)):
        for j in range(df.shape[1]):

            if pd.isnull(df.iloc[i, j]):
                 # def fill_missing_values(df1):
#     for i in range((df1.shape[0])):
#         if pd.isnull(df1.iloc[i,0]):
                 x_define = df.iloc[i, 0]
                 for k in range(i-1,-1,-1):
                    if pd.isnull(df.iloc[k,j]):
                        continue
                    else:
                        y_prev = df.iloc[k, j]
                        x_prev=df.iloc[k,0]
                        break
                    # df1=df[['stationid']]
# # print(df)
# def fill_missing_values(df1):
#     for i in range((df1.shape[0])):
#         if pd.isnull(df1.iloc[i,0]):
                 for h in range(i+1,df.shape[0]):
                     if pd.isnull(df.iloc[h,j]):
                         continue
                     else:
                         y_next=df.iloc[h,j]
                         x_next=df.iloc[h,0]
                         break
                 df.iloc[i, j] = linear_interpolation(x_prev, x_next, y_prev, y_next, x_define ) 
fill_missing_values(df)

print(df)

df.to_csv("ALLDetail1.csv")
df1 = pd.read_csv('ALLDetail1.csv')
print(df1)

# df.to_csv('ALLDetail.csv')
# df1=df[['stationid']]
# # print(df)
df2= pd.read_csv("ALLDetail1.csv")
mean = 0
for temp in df2['temperature']:
    mean += temp
mean = mean / df2['temperature'].count()
median = 0
temp_list = []
for temp in df2['temperature']:
    temp_list.append(temp)
temp_list.sort()
if len(temp_list) %2 == 0:
    median = (temp_list[len(temp_list)//2] + temp_list[len(temp_list)//2 - 1])/2
else:
    median = temp_list[len(temp_list)//2]
print("Mean:", round(mean, 2))
print("Median:", round(median, 2))
std = 0
mean = df2['temperature'].sum() / df2['temperature'].count()
for temp in df2['temperature']:
    std += (temp - mean) ** 2
std = np.sqrt(std / df2['temperature'].count())
print("Standard deviation:", round(std, 2))

mean = 0
for temp in df2['humidity']:
    mean += temp
mean = mean / df2['humidity'].count()
median = 0
temp_list = []
for temp in df2['humidity']:
    temp_list.append(temp)
temp_list.sort()
if len(temp_list) %2 == 0:
    median = (temp_list[len(temp_list)//2] + temp_list[len(temp_list)//2 - 1])/2
else:
    median = temp_list[len(temp_list)//2]
print("Mean:", round(mean, 2))
print("Median:", round(median, 2))
std = 0
mean = df2['humidity'].sum() / df2['humidity'].count()
for temp in df2['humidity']:
    std += (temp - mean) ** 2
std = np.sqrt(std / df2['humidity'].count())
print("Standard deviation:", round(std, 2))

mean = 0
for temp in df2['pressure']:
    mean += temp
mean = mean / df2['pressure'].count()
median = 0
temp_list = []
for temp in df2['pressure']:
    temp_list.append(temp)
temp_list.sort()
if len(temp_list) %2 == 0:
    median = (temp_list[len(temp_list)//2] + temp_list[len(temp_list)//2 - 1])/2
else:
    median = temp_list[len(temp_list)//2]
print("Mean:", round(mean, 2))
print("Median:", round(median, 2))
std = 0
mean = df2['pressure'].sum() / df2['pressure'].count()
for temp in df2['pressure']:
    std += (temp - mean) ** 2
std = np.sqrt(std / df2['pressure'].count())
print("Standard deviation:", round(std, 2))

mean = 0
for temp in df2['rain']:
    mean += temp
mean = mean / df2['rain'].count()
median = 0
temp_list = []
for temp in df2['rain']:
    temp_list.append(temp)
temp_list.sort()
if len(temp_list) %2 == 0:
    median = (temp_list[len(temp_list)//2] + temp_list[len(temp_list)//2 - 1])/2
else:
    median = temp_list[len(temp_list)//2]
print("Mean:", round(mean, 2))
print("Median:", round(median, 2))
std = 0
mean = df2['rain'].sum() / df2['rain'].count()
for temp in df2['rain']:
    std += (temp - mean) ** 2
std = np.sqrt(std / df2['rain'].count())
print("Standard deviation:", round(std, 2))

mean = 0
for temp in df2['lightavg']:
    mean += temp
mean = mean / df2['lightavg'].count()
median = 0
temp_list = []
for temp in df2['lightavg']:
    temp_list.append(temp)
temp_list.sort()
if len(temp_list) %2 == 0:
    median = (temp_list[len(temp_list)//2] + temp_list[len(temp_list)//2 - 1])/2
else:
    median = temp_list[len(temp_list)//2]
print("Mean:", round(mean, 2))
print("Median:", round(median, 2))
std = 0
mean = df2['lightavg'].sum() / df2['lightavg'].count()
for temp in df2['lightavg']:
    std += (temp - mean) ** 2
std = np.sqrt(std / df2['lightavg'].count())
print("Standard deviation:", round(std, 2))

mean = 0
for temp in df2['lightmax']:
    mean += temp
mean = mean / df2['lightmax'].count()
median = 0
temp_list = []
for temp in df2['lightmax']:
    temp_list.append(temp)
temp_list.sort()
if len(temp_list) %2 == 0:
    median = (temp_list[len(temp_list)//2] + temp_list[len(temp_list)//2 - 1])/2
else:
    median = temp_list[len(temp_list)//2]
print("Mean:", round(mean, 2))
print("Median:", round(median, 2))
std = 0
mean = df2['lightmax'].sum() / df2['lightmax'].count()
for temp in df2['lightmax']:
    std += (temp - mean) ** 2
std = np.sqrt(std / df2['lightmax'].count())
print("Standard deviation:", round(std, 2))

mean = 0
for temp in df2['moisture']:
    mean += temp
mean = mean / df2['moisture'].count()
median = 0
temp_list = []
for temp in df2['moisture']:
    temp_list.append(temp)
temp_list.sort()
if len(temp_list) %2 == 0:
    median = (temp_list[len(temp_list)//2] + temp_list[len(temp_list)//2 - 1])/2
else:
    median = temp_list[len(temp_list)//2]
print("Mean:", round(mean, 2))
print("Median:", round(median, 2))
std = 0
mean = df2['moisture'].sum() / df2['moisture'].count()
for temp in df2['moisture']:
    std += (temp - mean) ** 2
std = np.sqrt(std / df2['moisture'].count())
print("Standard deviation:", round(std, 2))
#end of the missing value
print("start of the original values start of orignal values original values")


df = pd.read_csv('landslide_data_original.csv')
lst1 = ['temperature','humidity','pressure','rain','lightavg','lightmax','moisture']
for coulumn in lst1:
    for temp in df[coulumn]:
        mean=0
        mean += temp
    mean = mean / df[coulumn].count()
    median = 0
    temp_list = []
    temp_list.append(temp)
    temp_list.sort()
    if len(temp_list) %2 == 0:
        median = (temp_list[len(temp_list)//2] + temp_list[len(temp_list)//2 - 1])/2
    else:
        median = temp_list[len(temp_list)//2]
    std = 0
    mean = df[coulumn].sum() / df[coulumn].count()  
    print("Mean:", round(mean, 2))
    print("Median:", round(median, 2))
for column in lst1:
    t1=df[column]
    t2= np.array(t1)
    #print(t2)
    mean = (t2.sum())/len(t2)
    l2=0
    for i in t2:
        j = (i-mean)**2
        l2+=j
    s= (l2/len(t2))**0.5
    print("standard deviation of the", column,  "is:", np.round(s,2))

''' start of the question  q2partb rmse'''
import matplotlib.pyplot as plt

# Read the data file
df = pd.read_csv('landslide_data_miss.csv')
df2 = pd.read_csv("ALLDetail1.csv")


rmse_dict = {}
for col in df.columns:
    for colu in df2.columns:
        if col != 'Time':
            df_temp = df[col] + df2[colu]
            rmse = np.sqrt((np.mean((df[col]) - df_temp)**2))
            rmse_dict[col] = rmse

# Plot the RMSEs with respect to the attributes
plt.bar(rmse_dict.keys(), rmse_dict.values())
plt.xlabel('Attribute')
plt.ylabel('RMSE')
plt.title('RMSE between original and replaced values for each attribute')
plt.show()




    
