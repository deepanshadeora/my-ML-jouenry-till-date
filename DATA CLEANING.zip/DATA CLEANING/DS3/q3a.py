import pandas as pd
import matplotlib.pyplot as plt

file = pd.read_csv('landslide_data_miss.csv')
interpolated = pd.read_csv('ALLDetail1.csv')

for l in file.columns[2:]:
    fig, ax = plt.subplots()
    ax.boxplot(interpolated[l])
    plt.xlabel(l)
    plt.ylabel("Value")
    plt.title("Boxplot of " + l)
    plt.show()
    

# import pandas as pd
# import matplotlib.pyplot as plt
# import numpy as np
# df = pd.read_csv('ALLDetail1.csv')
# lst=['temperature', 'humidity', 'pressure','rain','lightavg','lightmax','moisture']
# for col in lst:
#     w3=df[col]
#     w4= np.array(w3)
#     plt.boxplot(w4)
#     plt.xlabel(col)
#     plt.ylabel("Value")
#     plt.title("Boxplot of " + col)
#     plt.show()

