import pandas as pd
import numpy as np
# Read the data file
df = pd.read_csv('landslide_data_original.csv')
mean = 0
for temp in df['temperature']:
    mean += temp
mean = mean / df['temperature'].count()
median = 0
temp_list = []
for temp in df['temperature']:
    temp_list.append(temp)
temp_list.sort()
if len(temp_list) %2 == 0:
    median = (temp_list[len(temp_list)//2] + temp_list[len(temp_list)//2 - 1])/2
else:
    median = temp_list[len(temp_list)//2]
print("Mean:", round(mean, 2))
print("Median:", round(median, 2))
minimum = df['temperature'].iloc[0]
for temp in df['temperature']:
    if temp < minimum:
        minimum = temp

maximum = df['temperature'].iloc[0]
for temp in df['temperature']:
    if temp > maximum:
        maximum = temp

std = 0
mean = df['temperature'].sum() / df['temperature'].count()
for temp in df['temperature']:
    std += (temp - mean) ** 2
std = np.sqrt(std / df['temperature'].count())
print("Minimum:", round(minimum, 2))
print("Maximum:", round(maximum, 2))
print("Standard deviation:", round(std, 2))
