import matplotlib.pyplot as plt
import pandas as pd
import math

old_df = pd.read_csv("landslide_data_original.csv")

def innew_list(old_df, X_name, n):
    return [correlation_coefficient_pearson(old_df, X_name, 'temperature', n), correlation_coefficient_pearson(old_df, X_name, 'humidity', n), correlation_coefficient_pearson(old_df, X_name, 'pressure', n), correlation_coefficient_pearson(old_df, X_name, 'rain', n), correlation_coefficient_pearson(old_df, X_name, 'lightavg', n), correlation_coefficient_pearson(old_df, X_name, 'lightmax', n), correlation_coefficient_pearson(old_df, X_name, 'moisture', n)]

def correlation_coefficient_pearson(old_df ,X_name, Y_name, n):
    Xmean = old_df[X_name].mean()
    Ymean = old_df[Y_name].mean()

    X = 0
    Y = 0
    z = 0
    for i in range(0, n):
        x = old_df.loc[i][X_name] - Xmean
        y = old_df.loc[i][Y_name] - Ymean
        X += x**2
        Y += y**2
        z += x*y

    z = z/math.sqrt(X*Y)
    return z



n = len(old_df)
new_L = ['temperature','humidity','pressure','rain','lightavg','lightmax','moisture']
finale = pd.DataFrame({
    'temperature' : innew_list(old_df, 'temperature', n),
    #now for the humidity
    'humidity' : innew_list(old_df, 'humidity', n),
    #now for the pressure
    'pressure' : innew_list(old_df, 'pressure', n),
    #now for the rain
    'rain' : innew_list(old_df, 'rain', n),
    #now for the lightavg
    'lightavg' : innew_list(old_df, 'lightavg', n),
    #now for the lightmax
    'lightmax' : innew_list(old_df, 'lightmax', n),
    #finally for the moisture
    'moisture' : innew_list(old_df, 'moisture', n),
}, index = new_L)
print(finale)










