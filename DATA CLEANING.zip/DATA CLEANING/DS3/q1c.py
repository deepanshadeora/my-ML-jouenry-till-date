import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("landslide_data_original.csv")

data = df[df["stationid"] == "t12"]["humidity"]

bin_size = 5

plt.figure()
plt.hist(data, bins=bin_size)
plt.xlabel("Humidity")
plt.ylabel("Number of readings")
plt.title("Histogram of humidity for stationid = t12 (bin size = 5)")
plt.show()
