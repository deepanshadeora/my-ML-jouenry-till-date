import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
lst1 = ['temperature','humidity','pressure','rain','lightavg','lightmax','moisture']

df= pd.read_csv("landslide_data_original.csv")
rmse=[]
for column in lst1:
    sum1=0
    t1=df[column]
    t2= np.array(t1)
    t3=df[column]
    t4= np.array(t3)
    for i in range(len(t2)):
        x= (t4[i]-t2[i])**2
        sum1+=x
    r_value= (sum1/len(t2))**0.5
    rmse.append(r_value)

plt.plot(lst1,rmse)
plt.grid(color='blue',linestyle='--',linewidth=0.5)
plt.xlabel("Attribute")
plt.ylabel("RMSEs")
plt.title("RMSEs vs Attributes")
plt.show()