import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# Read the data
data = pd.read_csv('ALLdetail1.csv')


attributes = ['temperature', 'humidity', 'pressure', 'rain', 'lightavg', 'lightmax', 'moisture']

for attribute in attributes:
    lower_bound = np.percentile(data[attribute], 25) - 1.5 * np.percentile(data[attribute], 75)
    upper_bound = np.percentile(data[attribute], 75) + 1.5 * np.percentile(data[attribute], 75)
    
lst1 = ['temperature','humidity','pressure','rain','lightavg','lightmax','moisture']
for coulumn in lst1:
    for temp in data[coulumn]:
        median = 0
        temp_list = []
        temp_list.append(temp)
        temp_list.sort()
        if len(temp_list) %2 == 0:
            median = (temp_list[len(temp_list)//2] + temp_list[len(temp_list)//2 - 1])/2
        else:
            median = temp_list[len(temp_list)//2]
        
    data.loc[data[attribute] < lower_bound, attribute] = median
    data.loc[data[attribute] > upper_bound, attribute] = median    

data.plot(kind='box')
# plt.show()

# data = pd.read_csv('landslide_data_interpolated.csv')

attributes = ['temperature', 'humidity', 'pressure', 'rain', 'lightavg', 'lightmax', 'moisture']

for attribute in attributes:
    min_value = data[attribute].min()
    max_value = data[attribute].max()
    print('Min before normalization:', min_value)
    print('Max before normalization:', max_value)
    data[attribute] = (data[attribute] - min_value) / (max_value - min_value) * (12 - 5) + 5

for attribute in attributes:
    print('Attribute:', attribute)
    print('Min after normalization:', data[attribute].min())
    print('Max after normalization:', data[attribute].max())

lst= ['temperature','humidity','pressure','rain','lightavg','lightmax','moisture']
for attribute in lst:
    mean= np.mean(np.array(data[attribute]))
    std = np.std(np.array(data[attribute]))
    print('Attribute:', attribute)
    print('mean before normalization:', mean)
    print('standard deviation beforenormalization:', std)
    data[attribute] = (data[attribute] - mean) / std

for attribute in lst:
    print('Attribute:', attribute)
    print('mean after normalization:', np.mean(np.array(data[attribute])))
    print('standard deviation after normalization:', np.std(np.array(data[attribute])))    
