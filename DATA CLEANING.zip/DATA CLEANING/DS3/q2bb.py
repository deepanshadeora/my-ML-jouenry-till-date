import pandas as pd
import numpy as np
df = pd.read_csv("landslide_data_miss.csv")
new_df = df[['temperature', 'humidity', 'pressure','rain','lightavg','lightmax','moisture']]

# print(new_df)



def linear_interpolation(x_prev, x_next, y_prev, y_next):

    slope = (y_next - y_prev) / (x_next - x_prev)
    return x_prev + slope * (y_next - y_prev)

def fill_missing_values(new_df):
    for i in range(len(new_df)):
        for j in range((new_df.shape[1]-1)):
            if pd.isnull(new_df.iloc[i, j]):
                if i == 0:
                    x_prev = None
                else:
                    x_prev = new_df.iloc[i - 1, j]

                if i == new_df.shape[0] - 1:
                    x_next = None
                else:
                    x_next = new_df.iloc[i + 1, j]

                y_prev = new_df.iloc[i - 1, j+1] if x_prev is not None else None
                y_next = new_df.iloc[i + 1, j+1] if x_next is not None else None

                new_df.iloc[i, j] = linear_interpolation(x_prev, x_next, y_prev, y_next)

fill_missing_values(new_df)

print(new_df)
# new_df.to_csv("ALLDetail1.csv",index=False)
# new_df1 = pd.read_csv('ALLDetail1.csv')
# print(new_df1)
k=new_df.shape[1]-1
def fill_missing_values(new_df):
    for i in range(len(new_df)):
            if pd.isnull(new_df.iloc[i, k]):
                if i == 0:
                    x_prev = None
                else:
                    x_prev = new_df.iloc[i - 1, k]

                if i == new_df.shape[0] - 1:
                    x_next = None
                else:
                    x_next = new_df.iloc[i + 1, k]

                y_prev = new_df.iloc[i - 1, k-1] if x_prev is not None else None
                y_next = new_df.iloc[i + 1, k-1] if x_next is not None else None

                new_df.iloc[i, k] = linear_interpolation(x_prev, x_next, y_prev, y_next)

fill_missing_values(new_df)

print(new_df)


new_df=df[['stationid']]
# print(new_df)
def fill_missing_values(new_df):
    for i in range((new_df.shape[0])):
        if pd.isnull(new_df.iloc[i,0]):
         new_df.iloc[i,0]=new_df.iloc[i-1,0]
fill_missing_values(new_df)

print(new_df)
print(new_df['stationid'][10])  


