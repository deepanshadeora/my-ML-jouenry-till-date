import pandas as pd
import numpy as np
from scipy.stats import multivariate_normal
from sklearn.metrics import confusion_matrix, accuracy_score

# Load train and test datasets
train_data = pd.read_csv("iris_train.csv")
test_data = pd.read_csv("iris_test.csv")

# Extract features and labels from train and test datasets
X_train = train_data.drop("Species", axis=1)
y_train = train_data["Species"].values
X_train=X_train.drop("Unnamed: 0",axis=1)
X_test = test_data.drop("Species", axis=1)
X_test=X_test.drop("Unnamed: 0",axis=1)
y_test = test_data["Species"].values

# Calculate Species priors
Species_priors = {}
for label in np.unique(y_train):
    Species_priors[label] = np.sum(y_train == label) / len(y_train)

# Calculate mean and covariance matrices for each Species
Species_means = {}
Species_covs = {}
for label in np.unique(y_train):
    Species_data = X_train[y_train == label]
    Species_means[label] = np.mean(Species_data, axis=0)
    Species_covs[label] = np.cov(Species_data, rowvar=False)

# Multivariate Gaussian Naive Bayes Speciesifier
def predict(X, Species_means, Species_covs, Species_priors):
    predictions = []
    for sample in range(len(X)):
        Species_scores = []
        for label in Species_means:
            mean = Species_means[label]
            cov = Species_covs[label]
            prior = Species_priors[label]
            likelihood = multivariate_normal(mean=mean, cov=cov).pdf(X.iloc[sample])
            Species_scores.append(likelihood * prior)
        predicted_Species = np.argmax(Species_scores)
        predictions.append(predicted_Species)
    return np.array(predictions)

# Predict using the test data
predictions = predict(X_test, Species_means, Species_covs, Species_priors)
print(predictions)
class_labels = {
    0: 'Iris-setosa',
    1: 'Iris-versicolor',
    2: 'Iris-virginica'
}
predicted_labels = [class_labels[prediction] for prediction in predictions]

print("Predicted Classes for Test Data:")
print(predicted_labels)
predicted=pd.DataFrame(predicted_labels)

#Compute confusion matrix and accuracy
from sklearn.metrics import confusion_matrix, accuracy_score

confusion_m=confusion_matrix(test_data["Species"],predicted[0])
print("Confusion Matrix:")
print(confusion_m,"\n")
model_accuracy=((confusion_m[0,0]+confusion_m[1,1]+confusion_m[2,2])/np.sum(confusion_m))*100
print("Model's Accuracy:",model_accuracy)