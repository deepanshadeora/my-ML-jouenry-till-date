import pandas as pd
import numpy as np

df = pd.read_csv("iris_test.csv")
print(df.columns)
y4= df["Species"]

# print(y)
x1 = df.drop("Species", axis=1)
x1=x1.drop("Unnamed: 0",axis=1)
# print(x1)
X = x1 - np.mean(x1,axis=0)#mean subtrcted datat
# print(X)
C = np.dot(X.T, X)#covarriance matrix
eigvals, eigvecs = np.linalg.eig(C)
Q = eigvecs[:, :1]
X_reduced = np.dot(X, Q)#reduced data
X_test =X_reduced
# X_test.columns=['x0']
print(X_test)
##
df1= pd.read_csv("iris_train.csv")
# print(df1.columns)
y=np.array(df1.columns)
y2= df1["Species"]
# print(y)
x1 = df1.drop("Species", axis=1)
x1=x1.drop("Unnamed: 0",axis=1)
# print(x1)
X = x1 - np.mean(x1,axis=0)#mean subtrcted datat
# print(X)
C = np.dot(X.T, X)#covarriance matrix
eigvals, eigvecs = np.linalg.eig(C)
Q = eigvecs[:, :1]
X1_reduced = np.dot(X, Q)#reduced data
X_train=X1_reduced

# X_train.columns=['x0']
# print(X_train)
import math
# frames=[X_test,y]
# frames2=[X_train,y2]
# X_tested=pd.concat(frames,axis=1, join='inner')
# X_trained=pd.concat(frames2,axis=1, join='inner')

# Function to calculate mean of a list
def mean(numbers):
    return sum(numbers) / len(numbers)

# Function to calculate standard deviation of a list
def stdev(numbers):
    avg = mean(numbers)
    variance = sum([(x - avg) ** 2 for x in numbers]) / float(len(numbers) - 1)
    return math.sqrt(variance)

# Function to calculate Gaussian probability density function
def calculate_probability(x, mean, stdev):
    exponent = math.exp(-((x - mean) ** 2 / (2 * (stdev) ** 2)))
    return (1 / (math.sqrt(2 * math.pi) * stdev)) * exponent

# Calculate class priors
class_priors = {}
for label in set(y2):
    class_priors[label] = sum(1 for i in y2 if i == label) / len(y2)

# Calculate mean and standard deviation for each class
class_parameters = {}
for label in set(y2):
    class_data = [X_train[i][0] for i in range(len(X_train)) if y2[i] == label]
    class_parameters[label] = (mean(class_data), stdev(class_data))

# Classify test data
predictions = []
for data_point in X_test[:, 0]:
    class_probabilities = {}
    for label, (mean_val, stdev_val) in class_parameters.items():
        probability = calculate_probability(data_point, mean_val, stdev_val)
        class_probabilities[label] = class_priors[label] * probability
    predicted_class = max(class_probabilities, key=class_probabilities.get)
    predictions.append(predicted_class)
# Print predictions
# X_test["Predicted"]=predictions
print("Predicted Classes for Test Data:")
print(predictions)
predicted=pd.DataFrame(predictions)
print(predicted)
from sklearn.metrics import confusion_matrix, accuracy_score

confusion_m=confusion_matrix(df["Species"],predicted[0])
print("Confusion Matrix:")
print(confusion_m,"\n")
model_accuracy1=((confusion_m[0,0]+confusion_m[1,1]+confusion_m[2,2])/np.sum(confusion_m))*100
print("Model's Accuracy:",model_accuracy1)

