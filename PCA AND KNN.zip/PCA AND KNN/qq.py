import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import sklearn.model_selection
from collections import Counter 
from sklearn.metrics import confusion_matrix
from sklearn.metrics import ConfusionMatrixDisplay

# Read the iris.csv file into a Pandas DataFrame
df = pd.read_csv("Iris.csv")
print(df.columns)
y=np.array(df.columns)
print(y)
# Extract the attribute columns into a matrix
x1 = df.drop("Species", axis=1)
print(x1)
# Extract the target attribute into an array
y2 = df["Species"].values

uom=['SepalLengthCm','SepalWidthCm','PetalLengthCm','PetalWidthCm']
    
descrip=x1.describe() 
for column in uom:
    # t2=x1[column]
    # t1=np.array(t2)
    upper=descrip[column]['75%']
    lower=descrip[column]['25%']
    inter_quartile_range = upper-lower
    for j in range(len(x1[column])):
        median=descrip[column]['50%']
        if(not (lower - 1.5*inter_quartile_range < x1.at[j,column] < upper +1.5*inter_quartile_range)):
            x1.at[j,column]=median
            
#     d.append(t2)       
# #print(d) 
# m=np.array(d)
# # print(m)
# # for list in m:
# df1=pd.DataFrame(m).transpose()
# df1.columns=['SepalLengthCm','SepalWidthCm','PetalLengthCm','PetalWidthCm']
# print(df1)
def dataframe_to_matrix(x1):
  
  return x1.values
x=x1.values
print(x)#outliers corrected 

X = x - np.mean(x,axis=0)
print(X)
C = np.dot(X.T, X)
eigvals, eigvecs = np.linalg.eig(C)

# eigvals, eigvecs = eigvals[::-1], eigvecs[:, ::-1]
Q = eigvecs[:, :2]

X_reduced = np.dot(x, Q)

print( X_reduced)
df2=pd.DataFrame(X_reduced)
df2.to_csv('output.csv', index=False)
soa = np.array([[df2[0].mean(), df2[1].mean(), eigvals[0] * eigvecs[0][0], eigvals[0] * eigvecs[1][0]]])
soa1 = np.array([[df2[0].mean(), df2[1].mean(), eigvals[1] * eigvecs[0][1], eigvals[1] * eigvecs[1][1]]])
x0, y0, u0, v0 = zip(*soa)
x1, y1, u1, v1 = zip(*soa1)
plt.scatter(df2[0],df2[1])
plt.quiver(x0, y0, u0, v0, angles='xy', scale_units='xy',color='blue', scale=100, width=0.005,)
plt.quiver(x1, y1, u1, v1, angles='xy', scale_units='xy',color='blue', scale=25, width=0.005, label='Eigen Vectors')
plt.grid()
plt.show()




import math
#####################
X_reconstructed=np.dot(X_reduced,Q.T)
print(X_reconstructed)
df2=pd.DataFrame(X_reconstructed)
df2.columns=['SepalLengthCm','SepalWidthCm','PetalLengthCm','PetalWidthCm']
print(df2)
from sklearn.metrics import mean_squared_error

from sklearn.metrics import mean_squared_error

def compute_rmse(z, t):
  
  mse = mean_squared_error(z, t)

  rmse = math.sqrt(mse)

  return rmse

X = x

X_reconstructed = X_reconstructed

rmse_per_feature = []
for j in range(4):
  x = X[:, j]
  y = X_reconstructed[:, j]
  rmse = compute_rmse(x, y)
  rmse_per_feature.append(rmse)

# Print the RMSE for each feature.
print("RMSE per feature:", rmse_per_feature)

X_reduce_train,X_reduce_test,y_train,y_test= sklearn.model_selection.train_test_split(df2,y2,random_state=104,test_size=0.20,shuffle=True)

from collections import Counter
import numpy as np
from operator import itemgetter


actual_predicted = []

for k in range(len(X_reduce_test)):
    distances = []
    for z in range(len(X_reduce_train)):
        distance_ = np.sqrt(np.sum((X_reduce_test.iloc[k] - X_reduce_train.iloc[z]) ** 2))
        distances.append([distance_, y_train[z]])

    distances = sorted(distances, key=itemgetter(0))
    nearest_neighbors = distances[:5]
    nearest_neighbors_labels = [nearest_neighbors[1] for nearest_neighbors in nearest_neighbors]
    #predicted_class = Counter(nearest_neighbors_labels).most_common(1)[0][0]
    predicted_class = max(set(nearest_neighbors_labels), key=nearest_neighbors_labels.count)

    actual_predicted.append((y_test[k], predicted_class))


matrix = np.array(actual_predicted)
print("Matrix of class labels: \n")
print(matrix, "\n")

actual_label=matrix[:,0]
predicted_label=matrix[:,1]
confusion_mat=confusion_matrix(actual_label,predicted_label)
print(confusion_mat)
confusion_plot=ConfusionMatrixDisplay(confusion_mat)
confusion_plot.plot()
plt.show()

