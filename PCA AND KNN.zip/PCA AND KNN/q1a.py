import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import sklearn.model_selection
from collections import Counter 
from sklearn.metrics import confusion_matrix
from sklearn.metrics import ConfusionMatrixDisplay

# Read the iris.csv file into a Pandas DataFrame
df = pd.read_csv("Iris.csv")
print(df.columns)
y=np.array(df.columns)
print(y)
# Extract the attribute columns into a matrix
x1 = df.drop("Species", axis=1).values
print(x1)
# Extract the target attribute into an array
y2 = df["Species"].values
y2=np.array(y2)
data = pd.read_csv("Iris.csv")

attributes = ['SepalLengthCm','SepalWidthCm','PetalLengthCm','PetalWidthCm']

for attribute in attributes:
    lower_bound = np.percentile(data[attribute], 25) - 1.5 * np.percentile(data[attribute], 75)
    upper_bound = np.percentile(data[attribute], 75) + 1.5 * np.percentile(data[attribute], 75)
    
lst1 = ['SepalLengthCm','SepalWidthCm','PetalLengthCm','PetalWidthCm']
for coulumn in lst1:
    for temp in data[coulumn]:
        median = 0
        temp_list = []
        temp_list.append(temp)
        temp_list.sort()
        if len(temp_list) %2 == 0:
            median = (temp_list[len(temp_list)//2] + temp_list[len(temp_list)//2 - 1])/2
        else:
            median = temp_list[len(temp_list)//2]
        
    data.loc[data[attribute] < lower_bound, attribute] = median |  [data[attribute] > upper_bound, attribute] = median

#print(x)
#print(y)
# lst=[]
# uom=['SepalLengthCm','SepalWidthCm','PetalLengthCm','PetalWidthCm']
# for attribute in uom:
#     lst.append(df.attribute)
# #print(lst)    
#lst=[df['SepalLengthCm'],df['SepalWidthCm'],df['PetalLengthCm'],df['PetalWidthCm']]
# uom=['SepalLengthCm','SepalWidthCm','PetalLengthCm','PetalWidthCm']
# d=[]
# for column in uom:
#     t2=df[column]
#     t1=np.array(t2)
#     mean = np.mean(t2) 
#     median=np.median(t2)
#     std=np.std(t2)
#     upper= mean+3*std
#     lower= mean-3*std
#     for j in range(len(t2)):
#         if t2[j]> upper or t2[j]< lower:
#             t2[j]=median
#     d.append(t2)       
# #print(d) 
# m=np.array(d)
# # print(m)
# # for list in m:
# df1=pd.DataFrame(m).transpose()
# df1.columns=['SepalLengthCm','SepalWidthCm','PetalLengthCm','PetalWidthCm']
# print(df1)
# def dataframe_to_matrix(df1):
  
#   return df1.values
# x=df1.values
# print(x)

# # print(l)
# X = x - np.mean(x, axis=0)

# C = np.dot(X.T, X)
# eigvals, eigvecs = np.linalg.eig(C)

# eigvals, eigvecs = eigvals[::-1], eigvecs[:, ::-1]
# Q = eigvecs[:, :2]

# X_reduced = np.dot(x, Q)

# print( X_reduced)
# df2=pd.DataFrame(X_reduced)
# print(df2)

# # X_=df1-df1.mean()
# # corr_matrix=np.dot(X_.transpose(),X_)
# # eval,evec=np.linalg.eig(corr_matrix)
# # Q=evec[:,:2]
# # X_red=X_.dot(Q)
# # X_red[1]=-X_red[1]
# # print(X_red)
# # plt.scatter(X_red[0],X_red[1])
# # plt.show()
# X_=df1-df1.mean()
# corr_matrix=np.dot(X_.transpose(),X_)
# eval,evec=np.linalg.eig(corr_matrix)
# Q=evec[:,:2]
# X_red=X_.dot(Q)

# print(X_red)
# plt.scatter(X_red[0],X_red[1])
# plt.show()
# import math
# #####################
# X_reconstructed=np.dot(X_reduced,Q.T)
# print(X_reconstructed)

# from sklearn.metrics import mean_squared_error

# # from sklearn.metrics import mean_squared_error

# def compute_rmse(x, y):
  
#   mse = mean_squared_error(x, y)

#   rmse = math.sqrt(mse)

#   return rmse

# X = x

# X_reconstructed = X_reconstructed

# rmse_per_feature = []
# for j in range(4):
#   x = X[:, j]
#   y = X_reconstructed[:, j]
#   rmse = compute_rmse(x, y)
#   rmse_per_feature.append(rmse)

# # Print the RMSE for each feature.
# print("RMSE per feature:", rmse_per_feature)

# X_reduce_train,X_reduce_test,y_train,y_test= sklearn.model_selection.train_test_split(df2,y2,random_state=104,test_size=0.20,shuffle=True)

# from collections import Counter
# import numpy as np
# from operator import itemgetter

# K = 5
# actual_predicted = []

# for k in range(len(X_reduce_test)):
#     distances = []
#     for z in range(len(X_reduce_train)):
#         distance_ = np.sqrt(np.sum((X_reduce_test.iloc[k] - X_reduce_train.iloc[z]) ** 2))
#         distances.append([distance_, y_train[z]])

#     distances = sorted(distances, key=itemgetter(0))
#     nearest_neighbors = distances[:5]
#     nearest_neighbors_labels = [nearest_neighbors[1] for nearest_neighbors in nearest_neighbors]
#     #predicted_class = Counter(nearest_neighbors_labels).most_common(1)[0][0]
#     predicted_class = max(set(nearest_neighbors_labels), key=nearest_neighbors_labels.count)

#     actual_predicted.append((y_test[k], predicted_class))


# matrix = np.array(actual_predicted)
# print("Matrix of class labels: \n")
# print(matrix, "\n")
# # from sklearn.metrics import confusion_matrix

# # confusion_matrix = confusion_matrix(actual_predicted, predicted_class)
# # print(confusion_matrix)


# # from sklearn.metrics import confusion_matrix
# # actualone=matrix[:,0]
# # predictedone=matrix[:,1]
# # confuse_matrix=confusion_matrix(actualone,predictedone)
# # #print("Confusion Matrix: ")
# # print(confuse_matrix)
# # ConfusionMatrixDisplay(confuse_matrix,display_labels=['Class 1','Class 2','Class 3']).plot()
# # plt.show()






