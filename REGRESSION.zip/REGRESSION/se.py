import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression
from scipy.stats import pearsonr

# Load the dataset 
data = pd.read_csv('abalone.csv')

# Separate features and target variable
X = data.drop(columns=['Rings'])  # Features
y = data['Rings']  # Target variable

# Calculate Pearson correlation coefficients
correlations = {}
for column in X.columns:
    correlation, _ = pearsonr(X[column], y)
    correlations[column] = abs(correlation)

# Findthe attribute with the highest correlation with 'Rings'
best_attribute = max(correlations, key=correlations.get)

# Split the data into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X[best_attribute].values.reshape(-1, 1), y, test_size=0.2, random_state=42)

# Initialize dictionaries to store RMSE values
train_rmse = {}
test_rmse = {}

# Loop through different polynomial degrees (p = 2, 3, 4, 5)
for degree in range(2, 6):
    # Polynomial features transformation
    poly_features = PolynomialFeatures(degree=degree)
    X_train_poly = poly_features.fit_transform(X_train)
    X_test_poly = poly_features.transform(X_test)
    
    # Polynomial regression model
    model = LinearRegression()
    model.fit(X_train_poly, y_train)
    
    # Predictions
    y_train_pred = model.predict(X_train_poly)
    y_test_pred = model.predict(X_test_poly)
    
    # Calculatingg RMSE for training and test data
    train_rmse[degree] = np.sqrt(mean_squared_error(y_train, y_train_pred))
    test_rmse[degree] = np.sqrt(mean_squared_error(y_test, y_test_pred))

# Find the best-fit model based on the minimum test RMSE
best_degree = min(test_rmse, key=test_rmse.get)

# Plot RMSE vs Degree of Polynomial for training data
plt.figure(figsize=(8, 6))
plt.bar(train_rmse.keys(), train_rmse.values(), color='blue', label='Training RMSE')
plt.xlabel('Degree of Polynomial')
plt.ylabel('RMSE')
plt.title('Training RMSE vs Degree of Polynomial')
plt.xticks(list(train_rmse.keys()))
plt.legend()
plt.show()

# Plot RMSE vs Degree of Polynomial for test data
plt.figure(figsize=(8, 6))
plt.bar(test_rmse.keys(), test_rmse.values(), color='orange', label='Test RMSE')
plt.xlabel('Degree of Polynomial')
plt.ylabel('RMSE')
plt.title('Test RMSE vs Degree of Polynomial')
plt.xticks(list(test_rmse.keys()))
plt.legend()
plt.show()

# Plot the best-fit curve using the best-fit model on the training data
plt.figure(figsize=(8, 6))
plt.scatter(X_train, y_train, color='blue', label='Training Data')
plt.scatter(X_test, y_test, color='orange', label='Test Data')
poly_features = PolynomialFeatures(degree=best_degree)
X_poly = poly_features.fit_transform(X[best_attribute].values.reshape(-1, 1))
model = LinearRegression()
model.fit(X_poly, y)
X_range = np.linspace(X[best_attribute].min(), X[best_attribute].max(), 100).reshape(-1, 1)
X_range_poly = poly_features.transform(X_range)
y_range_pred = model.predict(X_range_poly)
plt.plot(X_range, y_range_pred, color='red', label='Best-fit Curve')
plt.xlabel(best_attribute)
plt.ylabel('Rings')
plt.title('Best-fit Curve using Polynomial Regression')
plt.legend()
plt.show()
