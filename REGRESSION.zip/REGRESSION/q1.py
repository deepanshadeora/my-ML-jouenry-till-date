import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split

# Read the abalone dataset
abalone_data = pd.read_csv("abalone.csv")

# Split the data into train and test sets (70% train, 30% test)
train_data, test_data = train_test_split(abalone_data, test_size=0.3, random_state=42)

# Save train and test data to CSV files
train_data.to_csv("abalone_train.csv", index=False)
test_data.to_csv("abalone_test.csv", index=False)

# Calculate Pearson correlation coefficients
correlations = train_data.corr(method='pearson')['Rings'].drop('Rings')

# Choose the attribute with the highest correlation with 'Rings'
best_attribute = correlations.abs().idxmax()

# Extract feature and target from training and test data
X_train = train_data[[best_attribute]].values
y_train = train_data['Rings'].values
X_test = test_data[[best_attribute]].values
y_test = test_data['Rings'].values

# Simple Linear Regression Model. in which we have first defined the class and then ithe illutsratess
class SimpleLinearRegression:
    def _init_(self):
        self.coef_ = 0
        self.intercept_ = 0
#X (independent variable) and y (dependent )
    def fit(self, X, y): 
        X_mean, y_mean = np.mean(X), np.mean(y)
        numerator, denominator = 0, 0
        for i in range(len(X)):
            numerator += (X[i] - X_mean) * (y[i] - y_mean)
            denominator += (X[i] - X_mean) ** 2
        self.coef_ = numerator / denominator
        self.intercept_ = y_mean - self.coef_ * X_mean

    def predict(self, X):
        return self.intercept_ + self.coef_ * X

# Build and train the Simple Linear Regression Model
regressor = SimpleLinearRegression()
regressor.fit(X_train, y_train)

# Predictions
y_train_pred = regressor.predict(X_train)
y_test_pred = regressor.predict(X_test)

# Calculate Root Mean Squared Error (RMSE)
E_rmse_testt=0
for i in range(len(y_test)):
    E_rmse_testt+=((y_test_pred[i]-y_test[i])**2)
    
rmse_test=(E_rmse_testt/len(y_test))**0.5    

E_rmse_trainn=0
for i in range(len(y_train)):
    E_rmse_trainn+=((y_train_pred[i]-y_train[i])**2)
    
rmse_train=(E_rmse_trainn/len(y_train))**0.5 

# Plot the best-fit line on the training data
plt.scatter(X_train, y_train, color='blue', label='Actual')
plt.plot(X_train, y_train_pred, color='red', linewidth=2, label='Predicted')
plt.xlabel(best_attribute)
plt.ylabel('Rings')
plt.title('Best-fit Line on Training Data')
plt.legend()
plt.show()

# Scatter plot of actual Rings vs predicted Rings on the test data
plt.scatter(y_test, y_test_pred)
plt.xlabel('Actual Rings')
plt.ylabel('Predicted Rings')
plt.title('Actual Rings vs Predicted Rings')
plt.show()

# Print RMSE on training and test data
print("Root Mean Squared Error (RMSE) on Training Data:", rmse_train)
print("Root Mean Squared Error (RMSE) on Test Data:", rmse_test)

#######################################q3############################################################################################
